# SpecificationAndRepository

Sample code for my blog post [.NET Core - Using the Specification pattern alongside a generic Repository](https://www.rodrigosantosdev.com/Blog/net-core--using-the-specification-pattern-alongside-a-generic-repository)
