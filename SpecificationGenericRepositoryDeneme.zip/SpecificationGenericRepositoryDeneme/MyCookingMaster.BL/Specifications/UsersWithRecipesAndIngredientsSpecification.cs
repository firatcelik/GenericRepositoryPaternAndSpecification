﻿using MyCookingMaster.BL.Models;
using System.Linq;

namespace MyCookingMaster.BL.Specifications
{
    public class UsersWithRecipesAndIngredientsSpecification : BaseSpecification<User>
    {
        public UsersWithRecipesAndIngredientsSpecification() : base(x => x.Recipes.Where(y => y.Name.Equals("Pizza")).Any())
      //  public UsersWithRecipesAndIngredientsSpecification() : base(x=>x.Recipes.Where(y=>y.Name.Equals("Pizza1")).Any())
       //public UsersWithRecipesAndIngredientsSpecification() : base(x => x.Name.Equals("John") && x.Recipes.Where(y => y.Name.Equals("Pizza1")).Any())
        // public UsersWithRecipesAndIngredientsSpecification() : base(x => x.Name.Equals("John"))
        {
            AddInclude(x => x.Recipes);
            AddInclude($"{nameof(User.Recipes)}.{nameof(Recipe.Ingredients)}");
        }

        public UsersWithRecipesAndIngredientsSpecification(int id) : base(x => x.Id == id)
        {
            AddInclude(x => x.Recipes);
            AddInclude($"{nameof(User.Recipes)}.{nameof(Recipe.Ingredients)}");
           
        }
    }
}
