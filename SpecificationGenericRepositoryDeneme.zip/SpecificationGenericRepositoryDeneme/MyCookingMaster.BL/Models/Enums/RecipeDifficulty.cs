﻿namespace MyCookingMaster.BL.Models.Enums
{
    public enum RecipeDifficulty
    {
        EASY,
        MEDIUM,
        HARD
    }
}
